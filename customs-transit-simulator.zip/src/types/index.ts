export type InterfaceLanguage = 'es' | 'fr' | 'ar' | 'en';
export type DocumentLanguage = 'es' | 'fr' | 'ar' | 'en';

export type PortOfEntry = 'TANGER_MED' | 'CASABLANCA' | 'AGADIR' | 'NADOR_WEST_MED' | 'KENITRA_ATLANTIC';

export type CustomsRegimeCode = 
  | '10_IMPORT_CONSOMMATION' 
  | '21_ATPA' 
  | '30_ENTREPOT' 
  | '40_TRANSIT';

export type TriageStatus = 'VALIDATED' | 'NEEDS_REVIEW' | 'FRAUD_OR_INCOMPLETE';

export type DiscrepancyType = 
  | 'WEIGHT_MISMATCH' 
  | 'HS_CODE_ERROR' 
  | 'INCOTERM_VALUATION' 
  | 'CURRENCY_MISMATCH' 
  | 'MISSING_CERTIFICATE' 
  | 'SCANNER_DENSITY_ALERT' 
  | 'SEAL_TAMPERED'
  | 'ORIGIN_MISMATCH';

export interface Discrepancy {
  id: string;
  type: DiscrepancyType;
  title: string;
  description: string;
  detectedByPlayer: boolean;
  severity: 'high' | 'medium' | 'low';
  impactMAD: number;
  expectedAction: 'REWEIGH' | 'PHYSICAL_INSPECTION' | 'RECTIFY_DUM' | 'REQUEST_CERTIFICATE' | 'APPLY_PENALTY' | 'REQUEST_SAMPLE' | 'PAY_GUARANTEE';
}

export interface ProductItem {
  id: string;
  description: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  totalPrice: number;
  declaredHsCode: string;
  correctHsCode: string;
  distractorHsCodes?: string[];
  ddiRate: number; // e.g. 0.025, 0.10, 0.175, 0.40
  tvaRate: number; // e.g. 0.20, 0.10, 0.14, 0.07
  tpRate: number; // 0.0025 (Taxe Parafiscale)
  isMcinetRequired: boolean; // Conformity MCINET
  isOnssaRequired: boolean; // Health/Phytosanitary ONSSA
  originCountry: string;
  preferentialDutyEligible: boolean; // EUR.1 / Free Trade
}

export interface InvoiceDoc {
  invoiceNumber: string;
  date: string;
  supplierName: string;
  supplierAddress: string;
  importerName: string;
  importerAddress: string;
  importerICE: string; // Identifiant Commun de l'Entreprise Marocaine
  importerIF: string; // Identifiant Fiscal
  incoterm: string; // CIF, FOB, CFR, EXW
  currency: string;
  exchangeRateToMAD: number;
  totalInvoiceAmount: number;
  freightCost?: number;
  insuranceCost?: number;
  suggestedRegimeHint?: string;
}

export interface PackingListDoc {
  docNumber: string;
  date: string;
  containerNumber: string;
  sealNumber: string;
  packagesCount: number;
  packageType: string;
  declaredNetWeightKg: number;
  declaredGrossWeightKg: number;
  volumeCbm: number;
}

export interface BillOfLadingDoc {
  blNumber: string;
  bookingRef?: string;
  carrierName: string;
  vesselName: string;
  voyageNumber: string;
  portOfLoading: string;
  portOfDischarge: string;
  notifyParty?: string;
  containerNumber: string;
  sealNumber: string;
  shippersWeightKg: number;
  freightPaymentStatus: 'PREPAID' | 'COLLECT';
  badStatus: 'DELIVERED' | 'PENDING' | 'BLOCKED' | 'LIVRÉ_PORTNET'; // Bon à Délivrer
}

export interface CertificateDoc {
  type: 'EUR1' | 'PHYTOSANITARY' | 'MCINET_COC' | 'CERTIFICATE_OF_ANALYSIS' | 'CERTIFICAT_ORIGINE_EUR1';
  certificateNumber: string;
  issuingAuthority: string;
  issueDate: string;
  expiryDate?: string;
  status: 'VALID' | 'EXPIRED' | 'MISSING' | 'IRREGULAR';
  remarks: string;
}

export interface DumDraftDoc {
  dumNumber: string; // Format: 000/2026/01/99999
  bureauDouane: string; // e.g. Tanger Med Port (400), Casablanca Port (300)
  regimeDouanier: CustomsRegimeCode;
  declarantICE: string;
  dateEnregistrement: string;
  cifValueMAD: number;
  calculatedDDI: number;
  calculatedTVA: number;
  calculatedTP: number;
  totalLiquidationMAD: number;
  statutCircuit: 'VERT' | 'ORANGE' | 'ROUGE'; // Circuit de dédouanement
}

export interface ControlTowerIncident {
  id: string;
  timestamp: string;
  type: 'SCANNER_ALERT' | 'SCALE_DISCREPANCY' | 'DEMURRAGE_CRITICAL' | 'PORTNET_LOCK' | 'ONSSA_SAMPLING' | 'WEATHER_HOLD';
  title: string;
  port: PortOfEntry;
  containerId: string;
  severity: 'critical' | 'warning' | 'info';
  status: 'active' | 'resolved' | 'escalated';
  minutesRemaining: number;
  penaltyPerMinuteMAD: number;
  description: string;
  options: {
    id: string;
    label: string;
    costMAD: number;
    timePenaltySeconds: number;
    actionType: 'REWEIGH' | 'PHYSICAL_INSPECTION' | 'RECTIFY_DUM' | 'PAY_GUARANTEE' | 'REQUEST_SAMPLE';
  }[];
}

export interface CustomsMission {
  id: string;
  title: string;
  level?: 'cadete' | 'inspector' | 'director';
  difficulty?: 'EASY' | 'MEDIUM' | 'HARD';
  description?: string;
  portOfEntry: PortOfEntry;
  vesselName?: string;
  estimatedArrival?: string;
  timeLimitMinutes?: number;
  clientCompany?: string;
  importerICE?: string;
  items: ProductItem[];
  invoice: InvoiceDoc;
  packingList: PackingListDoc;
  billOfLading: BillOfLadingDoc;
  certificates: CertificateDoc[];
  dumDraft: DumDraftDoc;
  scaleWeighbridgeWeightKg: number;
  scannerAnomalyDetected: boolean;
  scannerAnomalyLocation?: string;
  recommendedRegime: CustomsRegimeCode;
  discrepancies: Discrepancy[];
  demurrageTimerSeconds?: number;
  penaltyPerMinuteMAD: number;
  storyContext?: string;
  resolutionExplanation?: string;
}

export interface AdilTariffEntry {
  hsCode10: string; // e.g. "8708.91.90.00"
  hsCode6: string;
  chapter: string;
  heading: string;
  descriptionEs: string;
  descriptionFr: string;
  descriptionAr: string;
  descriptionEn: string;
  ddiPercent: number; // e.g. 2.5, 10, 17.5, 40
  tvaPercent: number; // e.g. 20, 10
  tpPercent: number; // 0.25
  agenciesRequired: ('MCINET' | 'ONSSA' | 'ANRT' | 'DNP' | 'MIN_SANTE')[];
  rgiNotes: string;
  unit: string;
}

export interface ChatMessage {
  id: string;
  sender: 'player' | 'inspector_ai' | 'system';
  text: string;
  timestamp: string;
  audioPlaying?: boolean;
}

export interface PlayerCustomsDecision {
  missionId?: string;
  selectedRegime: CustomsRegimeCode;
  itemsClassification?: {
    itemId: string;
    selectedHsCode: string;
    justificationRGI: string;
  }[];
  triageStatus: TriageStatus;
  detectedDiscrepancies: string[]; // discrepancy IDs
  demandedActions?: string[]; // e.g. 'PHYSICAL_INSPECTION', 'REWEIGH', 'RECTIFY_DUM'
  mainleveeDecision: 'GRANT_MAINLEVEE' | 'REFUSE_HOLD' | 'DEMAND_RECTIFICATION' | 'SEND_TO_PHYSICAL_VISITE';
  declaredCIF_MAD: number;
  calculatedTotalDuty_MAD: number;
  justificationNotes?: string;
}

export interface MissionAuditReport {
  scorePercent: number;
  ratingGrade: 'A+' | 'A' | 'B' | 'C' | 'F';
  isPassed: boolean;
  accuracyRate: number;
  taxCalculatedPlayerMAD: number;
  taxCalculatedOfficialMAD: number;
  taxDifferenceMAD: number;
  fraudPreventedCount: number;
  fraudMissedCount: number;
  demurragePenaltiesIncurredMAD: number;
  timeSpentSeconds: number;
  officialVerdict: 'MAINLEVEE_ACCORDEE' | 'MAINLEVEE_REFUSEE' | 'CONTENTIEUX_DOUANIER_AMENDE' | 'RECTIFICATION_VALIDEE';
  detailedCritique: string;
  recommendations: string[];
}
